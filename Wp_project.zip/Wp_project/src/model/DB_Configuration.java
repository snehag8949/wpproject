package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DB_Configuration {
	private static Connection conn = null;
	
	public static Connection connectToDB() {
		System.out.println("In Connection Establishment");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Registartion");
			conn =  DriverManager.getConnection("jdbc:mysql://localhost:3306/naukri", "root", "root");
			System.out.println("Connection established");
			return conn;
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Exception in connecting to DB " + ((Throwable) e).getMessage());
		}
		return null;
	}

	// create a method to close connection
	public static void closeConnection() {
		try {
			System.out.println("Connection closed");
			conn.close();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Exception in closing connection " + e.getMessage());
		}
	}
}
