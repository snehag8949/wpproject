package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.jdbc.Statement;

import pojo_class.adminlogpojo;
import pojo_class.adminpropojo;
import pojo_class.adminregpojo;
import pojo_class.logpojo;
import pojo_class.profilepojo;
import pojo_class.regpojo;

public class Registration_Model {
	public boolean insertReg(regpojo ro) {
		System.out.println("Test 2");
		Connection con = (Connection) DB_Configuration.connectToDB();
		try {
			String query = "insert into register(name,email,passwords,mobile_no) values(?,?,?,?)";
			PreparedStatement stmt = con.prepareStatement(query);
			stmt.setString(1, ro.getName());
			stmt.setString(2, ro.getMail());
			stmt.setString(3, ro.getPassword());
			stmt.setString(4, ro.getNumber());
			int i = stmt.executeUpdate();
			DB_Configuration.closeConnection();
			if (i > 0) {
				System.out.println("success");
				return true;
			} else {
				System.out.println("fail");
				return false;
			}

		} catch (Exception e) {
			System.out.println(" error" + e.getMessage());
		}
		return false;

	}

	public boolean checklog(logpojo lp) {
		// TODO Auto-generated method stub
		Connection con = (Connection) DB_Configuration.connectToDB();
		try {
			Statement stmt = (Statement) con.createStatement();
			ResultSet rs = stmt.executeQuery("select email,passwords from register where email= '" + lp.getEmail()
					+ "'and passwords='" + lp.getPassword() + "'");
			if (rs.next()) {
				if (rs.getString("email").equals(lp.getEmail())
						&& (rs.getString("passwords").equals(lp.getPassword()))) {
					return true;
				} else {
					return false;
				}
			}
		} catch (SQLException e) {
			System.out.println("error in check log " + e.getMessage());

		}
		return false;

	}

	public boolean insertprofile(profilepojo pp) {
		System.out.println("test profile");
		Connection con = (Connection) DB_Configuration.connectToDB();
		try {

			String query = "insert into profile(uname,gender,dob,qualification,year_of_passing,type_of_user,experience,email) values(?,?,?,?,?,?,?,?)";
			PreparedStatement stmt = con.prepareStatement(query);
			// System.out.println(pro.getEmail());
			stmt.setString(1, pp.getName());
			stmt.setString(2, pp.getGender());
			stmt.setString(3, pp.getDob());
			stmt.setString(4, pp.getQualification());
			stmt.setString(5, pp.getYop());
			stmt.setString(6, pp.getTou());
			stmt.setString(7, pp.getExperience());
			stmt.setString(8, pp.getEmail());
			// stmt.setString(8, pp.getEmail());
			int i = stmt.executeUpdate();
			DB_Configuration.closeConnection();
			if (i > 0) {
				System.out.println("success");
				return true;
			} else {
				System.out.println("fail");
				return false;
			}
		} catch (Exception e) {
			System.out.println("error in Reg model insertionprofile " + e.getMessage());
		}
		return false;

	}

	public profilepojo getusers(String email) {
		profilepojo user = new profilepojo();
		Connection con = DB_Configuration.connectToDB();
		Statement stmt;
		try {
			stmt = (Statement) con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from profile where email='" + email + "'");
			System.out.println("Email in get Users "+email);
			while (rs.next()) {
				// profilepojo user = new profilepojo();
				user.setEmail(rs.getString("email"));
				System.out.println("Email in GetUsers " + user.getEmail());
				user.setName(rs.getString("uname"));
				System.out.println(rs.getString("uname"));
				user.setDob(rs.getString("dob"));
				System.out.println(rs.getString("dob"));
				user.setGender(rs.getString("gender"));
				System.out.println(rs.getString("gender"));
				user.setQualification(rs.getString("qualification"));
				System.out.println(rs.getString("qualification"));
				user.setYop(rs.getString("year_of_passing"));
				System.out.println(rs.getString("year_of_passing"));
				user.setTou("type_of_user");
				System.out.println(rs.getString("type_of_user"));
				user.setExperience("experience");
				System.out.println(rs.getString("experience"));
				// users.add(user);
			}

			return user;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			System.out.println("Exception in getAllUSers " + e.getMessage());
		} finally {
			DB_Configuration.closeConnection();
		}

		return null;
	}

	public boolean checkactivation(logpojo lp) {
		Connection con = (Connection) DB_Configuration.connectToDB();
		try {
			Statement stmt = (Statement) con.createStatement();
			ResultSet rs = stmt.executeQuery("select activation from register where email='" + lp.getEmail() + "'");

			if (rs.next())
				if (rs.getString("activation").equals("y")) {
					System.out.println("Testing activation");
					return true;
				} else {
					System.out.println("Testing activation in else");
					return false;
				}

		} catch (SQLException e) {
			System.out.println("Exception" + e.getMessage());

		}
		return false;

	}

	public boolean updateactivation(String email) {
		Connection con = (Connection) DB_Configuration.connectToDB();
		try {
			System.out.println("updating..........");
			String query = "update register set activation='y' where email='" + email + "'";
			Statement stmt = (Statement) con.createStatement();
			int i = stmt.executeUpdate(query);
			if (i > 0)
				return true;
		} catch (SQLException e) {
			System.out.println("Exception" + e.getMessage());

		}
		return false;

	}

	public boolean checkadminlog(adminlogpojo ls) {
		Connection con = (Connection) DB_Configuration.connectToDB();
		try {
			Statement stmt = (Statement) con.createStatement();
			ResultSet rs = stmt.executeQuery("select email,passwords from adminregister where email= '" + ls.getEmail()
					+ "'and passwords='" + ls.getPassword() + "'");
			if (rs.next()) {
				if (rs.getString("email").equals(ls.getEmail())
						&& (rs.getString("passwords").equals(ls.getPassword()))) {
					return true;
				} else {
					return false;
				}
			}
		} catch (SQLException e) {
			System.out.println("error in check Adminlog " + e.getMessage());

		}
		return false;
	}

	public boolean checkadminactivation(adminlogpojo ls) {
		Connection con = (Connection) DB_Configuration.connectToDB();
		try {
			Statement stmt = (Statement) con.createStatement();
			ResultSet rs = stmt.executeQuery("select activation from adminregister where email='" + ls + "'");

			if (rs.getString("activation").equals("y")) {
				System.out.println("Testing activation");
				return true;
			} else {
				System.out.println("Testing activation in else");
				return false;
			}

		} catch (SQLException e) {
			System.out.println("Exception" + e.getMessage());

		}
		return false;

	}

	public boolean insertadminReg(adminregpojo arp) {
		System.out.println("Test 2");
		Connection con = (Connection) DB_Configuration.connectToDB();
		try {
			String query = "insert into adminregister(name,email,passwords,mobile_no) values(?,?,?,?)";
			PreparedStatement stmt = con.prepareStatement(query);
			stmt.setString(1, arp.getName());
			stmt.setString(2, arp.getMail());
			stmt.setString(3, arp.getPassword());
			stmt.setString(4, arp.getNumber());
			int i = stmt.executeUpdate();
			DB_Configuration.closeConnection();
			if (i > 0) {
				System.out.println("success");
				return true;
			} else {
				System.out.println("fail");
				return false;
			}

		} catch (Exception e) {
			System.out.println(" error in user register" + e.getMessage());
		}
		return false;

	}

	public boolean insertadminprofile(adminpropojo app) {

		System.out.println("test profile");
		Connection con = (Connection) DB_Configuration.connectToDB();
		try {

			String query = "insert into adminprofile(name,gender,dob,qualification,company,experience) values(?,?,?,?,?,?)";
			PreparedStatement stmt = con.prepareStatement(query);
			// System.out.println(pro.getEmail());
			stmt.setString(1, app.getName());
			stmt.setString(2, app.getGender());
			stmt.setString(3, app.getDob());
			stmt.setString(4, app.getQualification());
			stmt.setString(5, app.getCompany());
			stmt.setString(6, app.getExperience());

			int i = stmt.executeUpdate();
			DB_Configuration.closeConnection();
			if (i > 0) {
				System.out.println("success");
				return true;
			} else {
				System.out.println("fail");
				return false;
			}
		} catch (Exception e) {
			System.out.println("error in Reg model insertionprofile " + e.getMessage());
		}
		return false;
	}

	public boolean updateadminactivation(String email) {
		Connection con = (Connection) DB_Configuration.connectToDB();
		try {
			System.out.println("updating..........");
			String query = "update adminregister set activation='y' where email='" + email + "'";
			Statement stmt = (Statement) con.createStatement();
			int i = stmt.executeUpdate(query);
			if (i > 0){
				System.out.println("success");
				return true;}
			else{
				System.out.println("fail");
				return false;
			}
		} catch (SQLException e) {
			System.out.println("Exception" + e.getMessage());

		}
		return false;

	}

	public adminpropojo admingetusers(String email) {
		adminpropojo user = new adminpropojo();
		Connection con = DB_Configuration.connectToDB();
		Statement stmt;
		try {
			stmt = (Statement) con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from adminprofile where email='" + email + "'");
			while (rs.next()) {
				user.setEmail(rs.getString("email"));
				System.out.println("Email in GetUsers " + user.getEmail());
				user.setName(rs.getString("uname"));
				user.setDob(rs.getString("dob"));
				user.setGender(rs.getString("gender"));
				user.setQualification(rs.getString("qualification"));
				user.setCompany(rs.getString("company"));
				user.setExperience("experience");
				// users.add(user);
			}
			return user;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			System.out.println("Exception in getAllUSers " + e.getMessage());
		} finally {
			DB_Configuration.closeConnection();
		}

		return null;
	}

}
