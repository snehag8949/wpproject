package model;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.mysql.jdbc.Statement;

public class CheckingUser {

	public boolean exists(String email) {

		Connection con = DB_Configuration.connectToDB();
		try {
			Statement stmt = (Statement) con.createStatement();
			ResultSet rs = (ResultSet) stmt.executeQuery("select email from register where email ='" + email + "'");
			if (rs.next()) {
				System.out.println(rs.getString("email"));
				if (rs.getString("email").equals(email)) {
					System.out.println("Already exits");
					return true;
				} else {
					System.out.println("valid");
					return false;
				}
			}
		} catch (SQLException e) {
			// TODO: handle exception
			System.out.println("Exception" + e.getMessage());
		}
		return false;
	}
}
