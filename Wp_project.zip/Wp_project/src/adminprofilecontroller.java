
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Registration_Model;
import pojo_class.adminpropojo;
import pojo_class.profilepojo;

@WebServlet("/adminprofilecontroller")
public class adminprofilecontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public adminprofilecontroller() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out = response.getWriter();
		out.println("welcome to the admincontroller");
		adminpropojo app = new adminpropojo();
		String name = request.getParameter("uname");
		app.setName(name);
		String gen = request.getParameter("gender");
		app.setGender(gen);
		String dob = request.getParameter("dob");
		app.setDob(dob);
		String qua = request.getParameter("qualification");
		app.setQualification(qua);
		String company = request.getParameter("Company");
		app.setCompany(company);
		String exp = request.getParameter("experience");
		app.setExperience(exp);
		// System.out.println(exp);

		HttpSession session = request.getSession();

		String email = session.getAttribute("email").toString();
		app.setEmail(email);

		System.out.println(email);

		if (new Registration_Model().insertadminprofile(app)) {
			Registration_Model user = new Registration_Model();

			user.updateadminactivation(email);

			adminpropojo pfl = user.admingetusers(email);
			System.out.println("@@@@@@@ADMINPROFILE"+pfl.getEmail());
			session.setAttribute("use", pfl);

			System.out.println("*****************");
			try {
				System.out.println("----------------------");
				RequestDispatcher rd = request.getRequestDispatcher("/Adminusers.jsp");
				rd.forward(request, response);

			} catch (Exception e) {
				System.out.println("exception" + e.getMessage());
				// e.printStackTrace();
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
