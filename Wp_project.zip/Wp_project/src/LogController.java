
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Registration_Model;
import pojo_class.logpojo;
import pojo_class.profilepojo;
import pojo_class.regpojo;

/**
 * Servlet implementation class LogController
 */
@WebServlet("/LogController")
public class LogController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LogController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		System.out.println("test 1 login");
		PrintWriter out = response.getWriter();
		logpojo lp = new logpojo();
		String n = request.getParameter("email");
		lp.setEmail(n);
		String p = request.getParameter("password");
		lp.setPassword(p);

		if (new Registration_Model().checklog(lp)) {

			HttpSession session = request.getSession();
			session.setAttribute("email", n);
			System.out.println("Test 1 in log controller");
			if (new Registration_Model().checkactivation(lp)) {
				profilepojo pfl = new Registration_Model().getusers(n);
				
				System.out.println("Test 2 in log controller");
				session.setAttribute("use", pfl);

				RequestDispatcher rd = request.getRequestDispatcher("/users.jsp?error=AVAILABLE please continuee");
				rd.forward(request, response);
			} else {
				RequestDispatcher rd = request.getRequestDispatcher("/Profile.jsp?error=Please activate the profile");
				rd.forward(request, response);
			}

		} else {
			// out.println("Unavailable please check or register");
			RequestDispatcher rd = request.getRequestDispatcher("/index.jsp?error=UNAVAILABLE please register");
			rd.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
