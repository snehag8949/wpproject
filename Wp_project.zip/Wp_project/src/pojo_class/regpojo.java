package pojo_class;
public class regpojo {
	String name;
	String mail;
	String password;
	String cpassword;
	String number;
	String activation;
	public String getActivation() {
		return activation;
	}
	public void setActivation(String activation) {
		this.activation = activation;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCpassword() {
		return cpassword;
	}
	public void setCpassword(String cpassword) {
		this.cpassword = cpassword;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
//	@Override
//	public String toString() {
//		return "regpojo [name=" + name + ", mail=" + mail + ", password=" + password + ", cpassword=" + cpassword
//				+ ", number=" + number + "]";
//	}
	
}
