
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Registration_Model;
import pojo_class.adminregpojo;
import pojo_class.regpojo;

/**
 * Servlet implementation class RegController
 */
@WebServlet("/adminregcontroller")
public class adminregcontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public adminregcontroller() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());

		response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out = response.getWriter();

		System.out.println("Adminreg Test 1");
		adminregpojo arp = new adminregpojo();
		String name = request.getParameter("uname");
		arp.setName(name);
		String mail = request.getParameter("email");
		arp.setMail(mail);
		String pass = request.getParameter("password");
		arp.setPassword(pass);
		String cpass = request.getParameter("cpassword");
		arp.setCpassword(cpass);
		String no = request.getParameter("number");
		arp.setNumber(no);
		if (new Registration_Model().insertadminReg(arp)) {
//			out.println("Successfully Registered");
			 RequestDispatcher rd =request.getRequestDispatcher("/adminlogin.jsp?error=register successfully!!! please continue continue"); 
			 rd.forward(request,response);
		} else {
//			out.println("Error in Registration");
			
			  RequestDispatcher rd =request.getRequestDispatcher("/adminregister.jsp?error=Error in registration!!");
			  rd.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
