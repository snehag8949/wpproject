
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Registration_Model;
import pojo_class.adminlogpojo;
import pojo_class.logpojo;
import pojo_class.profilepojo;
import pojo_class.regpojo;

/**
 * Servlet implementation class LogController
 */
@WebServlet("/adminlogcontroller")
public class adminlogcontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public adminlogcontroller() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		System.out.println("test 1 Adminlogin");
		PrintWriter out = response.getWriter();
		adminlogpojo ls = new adminlogpojo();
		String a = request.getParameter("email");
		ls.setEmail(a);
		String b = request.getParameter("password");
		ls.setPassword(b);

		if (new Registration_Model().checkadminlog(ls)) {

			HttpSession session = request.getSession();
			session.setAttribute("email", a);

			if (new Registration_Model().checkadminactivation(ls)) {
				profilepojo pfl = new Registration_Model().getusers(a);

				session.setAttribute("use", pfl);

				RequestDispatcher rd = request.getRequestDispatcher("/users.jsp?error=AVAILABLE please continuee");
				rd.forward(request, response);
			} else {
				RequestDispatcher rd = request.getRequestDispatcher("/adminprofile.jsp?error=Please activate the profile");
				rd.forward(request, response);
			}

		} else {
			// out.println("Unavailable please check or register");
			RequestDispatcher rd = request.getRequestDispatcher("/adminlogin.jsp?error=UNAVAILABLE please register");
			rd.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
