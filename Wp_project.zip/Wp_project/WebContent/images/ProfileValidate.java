package package1;

import java.sql.*;
import java.util.ArrayList;

import PojoClasses.ProTab;

public class ProfileValidate {
	Connection conn;

	public ProfileValidate() {
		conn = null;
	}

	public boolean insert(ProTab pro) {
		try {
			System.out.println("Connection establishment");
			conn = DBConfig.connectToDB();
			System.out.println("Driver registered");
			PreparedStatement ps = conn.prepareStatement(
					"insert into profile(email,fname,lname,dob,gender,height,weight) VALUES (?, ?, ?, ?, ?, ?, ?)");
			//System.out.println(pro.getEmail()+" "+pro.getHeight());
			ps.setString(1, pro.getEmail());
			ps.setString(2, pro.getFname());
			ps.setString(3, pro.getLname());
			ps.setString(4, pro.getDob());
			ps.setString(5, pro.getGender());
			ps.setInt(6, pro.getHeight());
			ps.setDouble(7, pro.getWeight());
			
			System.out.println("Query Execution");
				 
			int i = ps.executeUpdate();
			if (i > 0){
				ps = conn.prepareStatement("update registration set status='YES' where email=?");
				//ps.setString(1, "YES");
				ps.setString(1, pro.getEmail());
				ps.execute();
				return true;
			}
			else{
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
			return false;
		}

	}

	public ArrayList<ProTab> getAllUsers() {
		// TODO Auto-generated method stub
		ArrayList<ProTab> users = new ArrayList<ProTab>();
		
		Connection con = DBConfig.connectToDB();
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from profile");
			while(rs.next()){
				ProTab user = new ProTab();
				user.setEmail(rs.getString("email"));
				user.setFname(rs.getString("fname"));
				user.setLname(rs.getString("lname"));
				user.setDob(rs.getString("dob"));
				user.setGender(rs.getString("gender"));
				user.setHeight(rs.getInt("height"));
				user.setWeight(rs.getDouble("weight"));
				
				users.add(user);
			}
			
			return users;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Exception in getAllUSers "+e.getMessage());
		}
		finally {
			DBConfig.closeConnection();
		}
		
		
		return null;
	}
	
	
}
