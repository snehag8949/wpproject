function validname()
{
	var x=document.getElementById("uname");
	/* alert("This is uname "+x.value); */
	if(x.value.length<5)
		{
		document.getElementById('error').innerHTML="&#x2717;";
     	document.getElementById('error').style.color="red";
	 	return false;
		}
	else
		{
		document.getElementById('error').innerHTML="&#x2713;";
     	document.getElementById('error').style.color="yellow";
	 	return true;
		}
}
function check_email()
{
	loaddoc();
	return true;
}
function loadDoc() {
	  var xhttp = new XMLHttpRequest();
	  var url = "checkingadminuser().exits()?mail=" + val;
	  xhttp.onreadystatechange = function() {
	    if (this.readyState == 4 && this.status == 200) {
	     document.getElementById("mail").innerHTML = this.responseText;
	    }
	  };
	  xhttp.open("GET", url, true);
	  xhttp.send();
	  
	}
 function validpassword()
{
	var z=document.getElementById("password");
    if(z.value.length>8)
    	{
    	document.getElementById('error2').innerHTML="&#x2713;";
     	document.getElementById('error2').style.color="yellow";
	 	return true;
    	}
    else
    	{
    	document.getElementById('error2').innerHTML="&#x2717;";
     	document.getElementById('error2').style.color="red";
	 	return false;
    	}
    
} 
 function validcpass()
 {
	 var p=document.getElementById("password");
	 var cp=document.getElementById("cpassword");
	 if(p.value.match(cp.value))
		 {
		    document.getElementById('error3').innerHTML="&#x2713;";
	     	document.getElementById('error3').style.color="yellow";
		 	return true;
		 }
	 else
		 {
		    document.getElementById('error3').innerHTML="&#x2717;";
	     	document.getElementById('error3').style.color="red";
		 	return false;
		 }
 }
 function validno()
 {
	 var a=document.getElementById("number");
	 if(a.value.length==10)
		 {
		    document.getElementById('error4').innerHTML="&#x2713;";
	     	document.getElementById('error4').style.color="yellow";
		 	return true;
		 }
	 else
		 {
		    document.getElementById('error4').innerHTML="&#x2717;";
	     	document.getElementById('error4').style.color="red";
		 	return false;
		 }
 }