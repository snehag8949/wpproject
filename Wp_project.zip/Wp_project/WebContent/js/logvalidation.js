function validEmail()
{
	var y=document.getElementById("email");
	var re = /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
	if(y.value.match(re))
		{
		document.getElementById('error1').innerHTML="&#x2713;";
     	document.getElementById('error1').style.color="yellow";
	 	return true;
		}
	else
		{
		document.getElementById('error1').innerHTML="&#x2717;";
     	document.getElementById('error1').style.color="red";
	 	return false;
		}
}
 function validpassword()
{
	var z=document.getElementById("password");
    if(z.value.length>8)
    	{
    	document.getElementById('error2').innerHTML="&#x2713;";
     	document.getElementById('error2').style.color="yellow";
	 	return true;
    	}
    else
    	{
    	document.getElementById('error2').innerHTML="&#x2717;";
     	document.getElementById('error2').style.color="red";
	 	return false;
    	}
    
} 